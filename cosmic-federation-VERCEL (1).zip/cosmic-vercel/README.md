# 🌌 Cosmic Federation

Interactive 3D Solar System & Galaxy Explorer — Three.js · React · WebGL · Web Audio

---

## Files in this repo

```
cosmic-federation/
├── public/
│   └── index.html        ← the entire app (230KB, self-contained)
├── vercel.json           ← Vercel config
├── netlify.toml          ← Netlify config
├── .gitignore
└── README.md
```

---

## Deploy on Vercel

1. Push this repo to GitHub (see below)
2. Go to **vercel.com** → **Add New Project**
3. Import your GitHub repo
4. In the configuration screen:
   - **Framework Preset:** `Other`
   - **Root Directory:** leave blank (`.`)
   - **Build Command:** leave blank
   - **Output Directory:** `public`
5. Click **Deploy** ✅

---

## Deploy on Netlify

**Option A — Drag & Drop (no account needed):**
1. Go to **app.netlify.com/drop**
2. Drag the `public` folder (just the folder, not the whole zip) onto the page
3. Live instantly ✅

**Option B — From GitHub:**
1. Netlify → **Add new site** → **Import an existing project**
2. Connect GitHub → select this repo
3. Build settings:
   - **Publish directory:** `public`
   - **Build command:** leave blank
4. Click **Deploy site** ✅

---

## Push to GitHub

1. Go to **github.com** → **+** → **New repository**
2. Name: `cosmic-federation` · Visibility: **Public** · click **Create**
3. On the next page click **"uploading an existing file"**
4. Unzip the downloaded package, then drag **all files and folders** into the GitHub uploader — including the `public/` folder
5. Click **Commit changes**
6. Done — now connect to Vercel or Netlify above ✅

---

## Controls

| Action | How |
|--------|-----|
| Rotate | Click + drag |
| Zoom | Scroll wheel |
| Select body | Click any planet or moon |
| Cinematic journey | ▶ button |
| Mute music | 🔇 button |
| Space agencies | Top tab bar |

---

## Credits

- Planet textures: Solar System Scope (CC BY 4.0)
- Milky Way: NASA/JPL-Caltech/R.Hurt (SSC-Caltech)
- Earth: NASA Apollo 17
- Andromeda: NASA/ESA Hubble
